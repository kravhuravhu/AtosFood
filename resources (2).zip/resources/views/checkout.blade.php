<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="author" content="Untree.co">
  <link rel="shortcut icon" href="favicon.png">

  <meta name="description" content="" />
  <meta name="keywords" content="" />

    <link href="https://fonts.googleapis.com/css?family=Cormorant+Garamond:400,500i,700|Roboto:300,400,500,700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="/css/vendor/icomoon/style.css">
    <link rel="stylesheet" href="/css/vendor/owl.carousel.min.css">
    <link rel="stylesheet" href="/css/vendor/aos.css">
    <link rel="stylesheet" href="/css/vendor/animate.min.css">
    <link rel="stylesheet" href="/css/vendor/bootstrap.css">

    <!-- Theme Style -->
    <link rel="stylesheet" href="/css/style.css">

    <title>Atos Food</title>
  </head>
  <body class="body-checkout">

    <div id="untree_co--overlayer"></div>
    <div class="loader">
      <div class="spinner-border text-primary" role="status">
        <span class="sr-only">Loading...</span>
      </div>
    </div>

    <nav class="untree_co--site-mobile-menu">
      <div class="close-wrap d-flex">
        <a href="#" class="d-flex ml-auto js-menu-toggle">
          <span class="close-label">Close</span>
          <div class="close-times">
            <span class="bar1"></span>
            <span class="bar2"></span>
          </div>
        </a>
      </div>
      <div class="site-mobile-inner"></div>
    </nav>


    <div class="untree_co--site-wrap">

      <nav class="untree_co--site-nav js-sticky-nav">
        <div class="container d-flex align-items-center">
          <div class="logo-wrap">
          <img src= "images/right.png" alt="logo" height="50px" width="70px">
          </div>
          <div class="site-nav-ul-wrap text-center d-none d-lg-block">
            <ul class="site-nav-ul js-clone-nav">
              <li><a href="home">Home</a></li>
              <li><a href="dashboard">Menu</a></li>
              <li  class="active"><a href="gallery">Gallery</a></li>
              <li><a href="about">About Us</a></li>
              <li><a href="contact">Contact</a></li>
            </ul>
          </div>
          <div class="icons-wrap text-md-right">

            <ul class="icons-top d-none d-lg-block">
              <li class="mr-4">
                <a href="#" class="js-search-toggle"><span class="icon-search2"></span></a>
                <!-----
                <input type="button" value="Login">
                <input type="button" value="Sign Up" class="">
-->
              </li>
             
            </ul>


            <!-- Mobile Toggle -->
            <a href="#" class="d-block d-lg-none burger js-menu-toggle" data-toggle="collapse" data-target="#main-navbar">
              <span></span>
            </a>
          </div>
        </div>
      </nav>


    <div class="untree_co--site-wrap">

      <nav class="untree_co--site-nav js-sticky-nav">
        <div class="container d-flex align-items-center">
          <div class="logo-wrap">
            <img src= "images/right.png" alt="logo" height="50px" width="80px">
          </div>
          <div class="site-nav-ul-wrap text-center d-none d-lg-block">
            <ul class="site-nav-ul js-clone-nav">
              <li><a href="home">Home</a></li>
              <li><a href="dashboard">Menu</a></li>
              <li><a href="gallery">Gallery</a></li>
              <li><a href="about">About Us</a></li>
              <li><a href="contact">Contact</a></li>
            </ul>
          </div>
          <div class="icons-wrap text-md-right">
            <!-- Mobile Toggle -->
            <a href="#" class="d-block d-lg-none burger js-menu-toggle" data-toggle="collapse" data-target="#main-navbar">
              <span></span>
            </a>
          </div>
        </div>
      </nav>



<div class="container-checkout">
    <h1 class="h1-checkout">Checkout</h1>

    <!-- Order Summary -->
    <div class="order-summary">
        <h2 class="ord-sum-text">Order Summary</h2>
        <table class="table-summary" id="checkoutItemsTable">
        <thead>
          <tr>
            <th>Image</th>
            <th>Name</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Total</th>
          </tr>
        </thead>
        <tbody id="checkoutItems">
          <!-- Items will be dynamically added here -->
        </tbody>
      </table>

      <div class="checkout-total">
        <h3>Total Amount: R<span id="totalAmount">0.00</span></h3>
      </div>
    </div>

    <!-- Customer Information -->
    <div class="customer-info">
        <h2 class="h2-checkout">Customer Information</h2>
        <form class="form-checkout"action="submit_order.php" method="POST">
            <label class="label-checkout" for="name">Name</label>
            <input class="input-checkout" type="text" id="name" name="name" required>

            <label class="label-checkout" for="email">Email</label>
            <input class="input-checkout" type="email" id="email" name="email" required>

            <label class="label-checkout" for="address">Deliver To</label>
            <textarea class="input-checkout" name="address" required id="selectedOptionsDisplay"></textarea>

            <label class="label-checkout" for="phone">Phone</label>
            <input class="input-checkout" type="tel" id="phone" name="phone" required>

            <label class="label-checkout" for="payment">Payment Method</label>
            <select id="payment" name="payment">
                <option value="credit_card">Credit Card</option>
                <option value="paypal">PayPal</option>
            </select>

            <label class="label-checkout" for="card_number">Credit Card Number</label>
            <input class="input-checkout" type="text" id="card_number" name="card_number">

            <label class="label-checkout" for="expiry_date">Expiry Date</label>
            <input class="input-checkout" type="text" id="expiry_date" name="expiry_date">

            <label class="label-checkout" for="cvv">CVV</label>
            <input class="input-checkout" type="text" id="cvv" name="cvv">

            <div class="terms">
                <p>By checking out, you agree to our <a href="#" id="terms-link">Terms and Conditions</a>.</p>
            </div>

            <button class="button-checkout" type="submit">Place Order</button>
        </form>
    </div>
</div>

 <!-- 
========================================================================
                        Modal for Terms and Conditions
========================================================================
 -->
  <div id="modal-checkout" class="modal">
    <div class="modal-content-checkout">
      <span class="close-checkout">&times;</span>
      <h2>Terms and Conditions</h2>
      <p>Here are the detailed terms and conditions...</p>
    </div>
  </div>
<!--
=====================================================================
                   Footer (About US, Social Media Details)
=====================================================================
---> 
<footer class="untree_co--site-footer">

<div class="container">
  <div class="row">
    <div class="col-md-4 pr-md-5">
      <h3>About Us</h3>
      <p>we're more than just a meal; we're a community. At Atos Food, we believe that food has the power to bring people together, and we're committed to creating an inviting atmosphere where you can gather with friends and family to enjoy great food and even better company.</p>
    </div>
    <div class="col-md-8 ml-auto">
      <div class="row">
        <div class="col-md-3">
          <h3>Navigation</h3>
          <ul class="list-unstyled">
            <li><a href="home">Home</a></li>
            <li><a href="dashboard">Menu</a></li>
            <li><a href="gallery">Gallery</a></li>
            <li><a href="about">About Us</a></li>
            <li><a href="contact">Contact</a></li>
          </ul>
        </div>
        <div class="col-md-9 ml-auto">
          <div class="row mb-3">
            <div class="col-md-6">
              <h3>Address</h3>
              <address>300 JANADEL AVENUE,HALFWAY HOUSE Midrand 1685 </address>
            </div>
            <div class="col-md-6">
              <h3>Telephone</h3>
              <p>
                <a href="#">+1 234 5678 910</a>
              </p>
            </div>
          </div>

        </div>
        
      </div>
    </div>
  </div>
  <div class="row mt-5 pt-5 align-items-center">
    <div class="col-md-6 text-md-left">
      <p>
        Copyright &copy;<script>document.write(new Date().getFullYear());</script> <a href="index.html">Atos</a>. All Rights Reserved. Design by <a href="#" target="_blank" class="text-primary">Atos</a>
      </p>
    <!-- Link back to Untree.co can't be removed. Template is licensed under CC BY 3.0. If you purchased a license you can remove this. -->
    </div>
    <div class="col-md-6 text-md-right">
      <ul class="icons-top icons-dark">
      <li>
<a href="https://www.facebook.com/Atos/"><span class="icon-facebook"></span></a>
</li>
<li>
<a href="https://www.twitter.com/Atos/"><span class="icon-twitter"></span></a>
</li>
<li>
<a href="https://www.instagram.com/Atos/"><span class="icon-instagram"></span></a>
</li>
<li>
<a href="https://www.linkedin.com.company/1259"><span class="icon-linkedin"></span></a>
</li>
<li>
<a href="https://www.youtube.com.user/atos"><span class="icon-youtube"></span></a>
</li>
    </ul>

    </div>
  </div>
</div>

</footer>
</div>



<script src="/js/vendor/jquery-3.3.1.min.js"></script>
<script src="/js/vendor/popper.min.js"></script>
<script src="/js/vendor/bootstrap.min.js"></script>

<script src="/js/vendor/owl.carousel.min.js"></script>

<script src="/js/vendor/jarallax.min.js"></script>
<script src="/js/vendor/jarallax-element.min.js"></script>
<script sr c="/build/assetsjs/vendor/ofi.min.js"></script>

<script src="/js/vendor/aos.js"></script>

<script src="/js/vendor/jquery.lettering.js"></script>
<script src="/js/vendor/jquery.sticky.js"></script>

<script src="/js/vendor/TweenMax.min.js"></script>
<script src="/js/vendor/ScrollMagic.min.js"></script>
<script src="/js/vendor/scrollmagic.animation.gsap.min.js"></script>
<script src="/js/vendor/debug.addIndicators.min.js"></script>
<script>
        document.addEventListener('DOMContentLoaded', function() {
            // Retrieve selectedOptions from localStorage
            var selectedOptionsJSON = localStorage.getItem('selectedOptions');
            
            if (selectedOptionsJSON) {
                var selectedOptions = JSON.parse(selectedOptionsJSON);
                
                // Display selected options in a <textarea>
                var selectedOptionsTextarea = document.getElementById('selectedOptionsDisplay');
                selectedOptionsTextarea.textContent = selectedOptions.join('\n');
            } else {
                // Handle case where no options were previously selected
                var selectedOptionsTextarea = document.getElementById('selectedOptionsDisplay');
                selectedOptionsTextarea.textContent = 'No options selected.';
            }
        });
  </script>
<script src="/js/main.js"></script>
</body>
</html>