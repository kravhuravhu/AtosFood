<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="../css/login_styles.css">
</head>
<body>
    <div class="login-container">
        <img src="/images/right.png" alt="logo" width="100px" height="100px" style="display: block; margin: 0 auto 20px auto;">
        <h2>Sign in</h2>
        <form id="loginForm">
            <div class="input-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="input-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit">Login</button>
            <p id="error-message"></p>
        </form>
    </div>
    <script>
        document.getElementById('loginForm').addEventListener('submit', function(event) {
        event.preventDefault();

        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const errorMessage = document.getElementById('error-message');

        const adminEmail = "admin_@atosfood.net";
        const adminPassword = "1234";

        const userEmail = "hart@atosfood.net";
        const userPassword = "kk";

        if (email === adminEmail && password === adminPassword) {
            localStorage.setItem('role', 'admin');
            errorMessage.textContent = '';
            alert('Login successful!');
            window.location.href = 'http://127.0.0.1:5501/public/admin/index.html';
        } else if (email === userEmail && password === userPassword) {
            localStorage.setItem('role', 'user');
            errorMessage.textContent = '';
            alert('Login successful!');
            window.location.href = "http://127.0.0.1:5501/public/admin/index.html";
        } else {
            errorMessage.textContent = 'Invalid email or password';
        }
    });
    </script>

</body>
</html>
